
public class Normal extends Ingresso {

	public String Imprimetipo() {
		return ("Ingresso Normal");
	}

}
