
public class CamaroteSuperior extends VIP {
    private double adicional;
    private int localizacao;

    public double getAdicional() {
        return adicional;
    }

    public void setAdicionalcs(double adicional) {
        this.adicional = adicional;
    }

    public int getLocalizacao() {
        return localizacao;
    }

    public void setLocalizacao(int localizacao) {
        this.localizacao = localizacao;
    }
    
    public double ImprimeValor(){
        return this.valor+this.valorAdicional+this.adicional;
    }
    


}
