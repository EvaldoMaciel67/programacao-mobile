
public class Atividade6 {
	public static void main(String[] args) {
		

		Ingresso ingresso = new Ingresso();
		Normal ingressoNormal = new Normal();
		VIP ingressoVip = new VIP();
		CamaroteSuperior ingressoCamaroteSup = new CamaroteSuperior();
		CamaroteInferior ingressoCamaroteinf = new CamaroteInferior();
		
		ingresso.setValor(10);
		ingressoNormal.setValor(ingresso.valor);
		
		
		ingressoVip.setValor(ingresso.valor);
		ingressoVip.setValorAdicional(10);
		
		ingressoCamaroteinf.setValor(ingresso.valor);
		ingressoCamaroteinf.setValorAdicional(ingressoVip.getValorAdicional());
		
		ingressoCamaroteSup.setValor(ingresso.valor);
		ingressoCamaroteSup.setValorAdicional(ingressoVip.getValorAdicional());
		ingressoCamaroteSup.setAdicionalcs(20);		

		System.out.println("Valor Ingresso: "+ ingresso.ImprimeValor());
		System.out.println("Valor Normal: "+ ingressoNormal.ImprimeValor());
		System.out.println("Valor VIP: "+ ingressoVip.ImprimeValor());
		System.out.println("Valor Camarote Inf.: "+ ingressoCamaroteinf.ImprimeValor());
		System.out.println("Valor Camarote Sup.: "+ingressoCamaroteSup.ImprimeValor());
			
		
		
	}
}
